﻿using System;

namespace Lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            n = Convert.ToInt32(Console.ReadLine());

            if(n%9 == 0 || n%11 == 0 || n%13 == 0)
            {
                Console.WriteLine(true);

            }
            else
            {

                Console.WriteLine(false);

            }
        }
    }
}
