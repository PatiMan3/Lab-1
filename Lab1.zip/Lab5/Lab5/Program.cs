﻿using System;


    class Program
    {
        static void Main()
        {
        double a;
        double b;
        double c;
        double aver;

        a = Convert.ToDouble(Console.ReadLine());
        b = Convert.ToDouble(Console.ReadLine());
        c = Convert.ToDouble(Console.ReadLine());

        aver = (a + b + c) / 3;
        Console.WriteLine(aver);
    }
    }

