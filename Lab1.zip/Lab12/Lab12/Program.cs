﻿using System;

namespace Lab12
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            int c = 0;

            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToInt32(Console.ReadLine());

            if ((a * b * c) > 0)
            {
                Console.WriteLine("Positiv");
            }
            else if ((a * b * c) < 0)
            {
                Console.WriteLine("Negative");
            }
        }
    }
}
