﻿using System;

namespace Lab11
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            int c = 0;
            int max = 0;

            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToInt32(Console.ReadLine());

            if(a>b && a>c)
            {
                Console.WriteLine(a);

            }
            else if(b>a && b>c)
            {

                Console.WriteLine(b);

            }
            else if (c > a && c > b)
            {

                Console.WriteLine(c);

            }
            else if (a == b && a ==c)
            {

                Console.WriteLine(a);

            }
        }
    }
}
