﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;




    class Program
    {
        static void Main()
        {
            int[] b = new int[100];
            Console.WriteLine("Write number of nums - ");
            int a = 0;
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Write Your Num - ");
            for (int i = 0; i < a; i++)
            {
                b[i] = Convert.ToInt32(Console.ReadLine());          
            }

            Console.WriteLine("Your nums");

        for (int i = 0; i < a; i++)
        {
            Console.WriteLine(b[i]);
        }

    }
    }
