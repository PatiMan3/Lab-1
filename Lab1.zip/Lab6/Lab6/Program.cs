﻿using System;


    class Program
    {
        static void Main()
        {
        double a = 0;
        double b = 0;
        double h = 0;
        double area = 0;

        a = Convert.ToDouble(Console.ReadLine());
        b = Convert.ToDouble(Console.ReadLine());
        h = Convert.ToDouble(Console.ReadLine());

        area = ((a + b) / 2) * h;

        Console.WriteLine(area);
    }
    }

