﻿using System;

namespace Lab9
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            num = Convert.ToInt32(Console.ReadLine());
            if(num > 20)
            {
                Console.WriteLine(true);

            }
            else
            {

                Console.WriteLine(false);

            }
        }
    }
}
