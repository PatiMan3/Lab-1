﻿using System;

namespace Lab13
{
    class Program
    {
        static void Main(string[] args)
        {
            string selection = Console.ReadLine();
            switch (selection)
            {
                case "1":
                    Console.WriteLine("Monday");
                    break;
                case "2":
                    Console.WriteLine("Tuesday");
                    break;
                case "3":
                    Console.WriteLine("Wednesday");
                    break;
                case "4":
                    Console.WriteLine("terthdat");
                    break;
                case "5":
                    Console.WriteLine("friday");
                    break;
                case "6":
                    Console.WriteLine("Sunday");
                    break;
                case "7":
                    Console.WriteLine("satday");
                    break;
                default:
                    Console.WriteLine("not valid");
                    break;
            }
        }
    }
}
