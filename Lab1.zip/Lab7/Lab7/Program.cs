﻿using System;


    class Program
    {
        static void Main()
        {
        int n;
        int LastDigit;

        n = Convert.ToInt32(Console.ReadLine());

        LastDigit = n %(10);

        Console.WriteLine(LastDigit);

    }
    }

