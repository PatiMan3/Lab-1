﻿using System;


    class Program
    {
        static void Main()
        {
        int n;
        int nDigit;
        int num;

        num = Convert.ToInt32(Console.ReadLine());
        n = Convert.ToInt32(Console.ReadLine());

        nDigit = (num / (10 ^ (n - 1))) % 10;

        Console.WriteLine(nDigit);
         
    }
    }

