﻿using System;



    class PrintYourColor
    {   
        static void Main()
        {
  
            Console.WriteLine("Green/Black/Purpure!");
                                                        
        }
    }
