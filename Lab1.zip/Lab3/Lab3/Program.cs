﻿using System;


    class Program
    {
        static void Main()
        {

        Console.WriteLine("Write your num - ");

        double a = 0;
        double b = 0;
        double c = 0;

         a = Convert.ToDouble(Console.ReadLine());
         b = Convert.ToDouble(Console.ReadLine());
         c = Convert.ToDouble(Console.ReadLine());


        Console.WriteLine("---------------------------------------w--------------------------------");

        Console.WriteLine(a);
        Console.WriteLine(b);
        Console.WriteLine(c);

    }
    }
