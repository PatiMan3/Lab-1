﻿using System;


    class Program
    {
        static void Main()
        {
        string a = "Software University";
        string b = "B";
        string c = "e";
        string d = "y";
        string e = "I love programming";

        Console.WriteLine(a);
        Console.WriteLine(b);
        Console.WriteLine(c);
        Console.WriteLine(d);
        Console.WriteLine(e);


    }
}

